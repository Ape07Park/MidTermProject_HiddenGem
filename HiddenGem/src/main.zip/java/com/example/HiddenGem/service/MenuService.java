package com.example.HiddenGem.service;

import java.util.List;

import com.example.HiddenGem.entity.Menu;



public interface MenuService {
	

//	List<Menu> getMenuList(String foodTitle);
	
	Menu getMenuByName (String name);

}
