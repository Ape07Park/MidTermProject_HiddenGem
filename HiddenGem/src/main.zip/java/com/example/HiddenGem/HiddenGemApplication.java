package com.example.HiddenGem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HiddenGemApplication {

	public static void main(String[] args) {
		SpringApplication.run(HiddenGemApplication.class, args);
	}

}
